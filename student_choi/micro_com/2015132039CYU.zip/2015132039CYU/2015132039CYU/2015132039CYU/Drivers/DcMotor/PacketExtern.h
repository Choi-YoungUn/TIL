
int PacketExtractFromBuffer(circ_bbuf_t *circ_buff, typePacket *packet);
void PacketParsing(typePacket *packet);

extern uint16_t countPacket;