#ifndef _SUPPORT_TESTS_H_
#define _SUPPORT_TESTS_H_

/*--------------------------------------------------------------------------------*/
/* Test/Group Declarations */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(copy_tests);
JTEST_DECLARE_GROUP(fill_tests);
JTEST_DECLARE_GROUP(x_to_y_tests);

#endif /* _SUPPORT_TESTS_H_ */
